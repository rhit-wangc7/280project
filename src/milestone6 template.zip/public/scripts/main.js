/**
 * @fileoverview
 * Provides the JavaScript interactions for all pages.
 *
 * @author 
 * PUT_YOUR_NAME_HERE
 */

/** namespace. */
var rhit = rhit || {};
rhit.FB_COLLECTION_POSTS = "Posts";
rhit.FB_COLLECTION_USERS = "Users";
rhit.FB_KEY_DESCRIPTION = "Description";
rhit.FB_KEY_CONDITION = "Condition";
rhit.FB_KEY_IMAGE_URL = "imageUrl";
rhit.FB_KEY_TYPE = "Type";
rhit.FB_KEY_NAME = "Name";
rhit.FB_KEY_LAST_TOUCHED = "lastTouched";
rhit.FB_KEY_OWNER = "Owner";
rhit.fbItemsManager = null;
rhit.fbDetailItemManager = null;

/** globals */
rhit.variableName = "";


// From https://stackoverflow.com/questions/494143/creating-a-new-dom-element-from-an-html-string-using-built-in-dom-methods-or-pro/35385518#35385518
function htmlToElement(html) {
	var template = document.createElement('template');
	html = html.trim();
	template.innerHTML = html;
	return template.content.firstChild;
}

rhit.Post = class{
	constructor(id, name, url){
		this.id = id;
		this.name = name;
		this.url = url;
	}
}

rhit.startFirebaseUI = () =>{
	// FirebaseUI config.
	var uiConfig = {
        signInSuccessUrl: '/',
        signInOptions: [
          // Leave the lines as is for the providers you want to offer your users.
          firebase.auth.GoogleAuthProvider.PROVIDER_ID,
          firebase.auth.EmailAuthProvider.PROVIDER_ID,
          firebase.auth.PhoneAuthProvider.PROVIDER_ID,
          firebaseui.auth.AnonymousAuthProvider.PROVIDER_ID
        ]
      
      };

      var ui = new firebaseui.auth.AuthUI(firebase.auth());
      // The start method will wait until the DOM is loaded.
      ui.start('#firebaseui-auth-container', uiConfig);
}

rhit.HomePageController = class{
	constructor(){
		$("#account").click(()=>{
			window.location.href = `loginPage.html`
		})
	}


}

rhit.ListPageController = class{
	constructor(){
		$("#account").click(()=>{
			window.location.href = `loginPage.html`
		})
		// const url = document.querySelector("#name").value;
		// rhit.fbItemsManager.add(name,url);
		rhit.fbItemsManager.beginListening(this.updateList.bind(this));
	}

	updateList(){
		console.log("need to update list.");
		console.log(`Num of items = ${rhit.fbItemsManager.length}`);
		// console.log("Example quote = ", rhit.fbItemsManager.getMovieQuoteAtIndex(0) );

		// new List 
		const newList = htmlToElement(' <div id="Container"></div>');
		for (let i =0; i<rhit.fbItemsManager.length;i++){
			const item = rhit.fbItemsManager.getItemAtIndex(i);
			console.log(item.name);
			const newItem = this._createItem(item);
			
			newItem.onclick = (event) => {
				console.log(`you clicked on ${item.id}`);
				window.location.href = `/DetailPage.html?id=${item.id}`;
				console.log("you are in the detail page");
				
			}
			newList.appendChild(newItem);
		}
		const oldList = document.querySelector("#Container");
		// Put in the new quoteListContainer
		oldList.removeAttribute("id");
		oldList.hidden = true;
		oldList.parentElement.appendChild(newList);
		
	}
	_createItem(Post){
		return htmlToElement(` <div class = "post px-0 my-4"><img style = "border-radius: 5px;" src="${Post.url}"alt="${Post.name}">
		<div class="text-center h2 col-7" style="padding-right: 10%;">${Post.name}</div></div>`);
	};

	// _updateItem(detail){
	// 	return htmlToElement(`<div class = "detail px-0 my-4">
	// 			<img style = "border-radius: 5px;" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQeOsPJFvyMnu7OpgcuMRY_2smSzr9vsCXSXw&usqp=CAU" alt="Harry Potter">
	// 		  </div>
	// 		  <div class = "information px-0 my-4" >
	// 			  <p>Owner: Tony Chen</p>
	// 			  <p>Item ID #88888</p>
	// 			  <p>Condition: Like new</p>
	// 			  <p>Email: cheny33@rose-hulman.edu</p>
	// 			  <p>Description: This is my favorite book!</p>
	// 		  </div>`);
	// }


}


rhit.DetailPageController = class {
	constructor(){
		$("#account").click(()=>{
			window.location.href = `loginPage.html`
		})

		$("#favoriteBut").click(()=>{
			window.location.href = `loginPage.html`
		})

		$("#contactBut").click(()=>{
			window.location.href = `loginPage.html`
		})

		

		rhit.fbDetailItemManager.beginListening(this.updateView.bind(this));
	}
	
	updateView(){
		console.log(rhit.fbDetailItemManager.Description);
		document.getElementById("Name").innerText = `Name:${rhit.fbDetailItemManager.Name}`;
		document.getElementById("Owner").innerText = `Owner:${rhit.fbDetailItemManager.Owner}`;
		// document.getElementById("Email").innerText = `Owner:${rhit.fbDetailItemManager.Email}`;
		document.getElementById("Condition").innerText = `Condition: ${rhit.fbDetailItemManager.Condition}`;
		document.getElementById("Description").innerText = `Description: ${rhit.fbDetailItemManager.Description}`;
		document.getElementById("myImg").src = rhit.fbDetailItemManager.url;

		
	}

}











// All Manager at here !!!!!!!!!!!!!!

rhit.FbItemsManager = class {
	constructor(){
		this.users = null;
		this._ref = firebase.firestore().collection(rhit.FB_COLLECTION_POSTS);
		console.log(this._ref);
		this._documentSnapshots = [];
		this._unsubscribe = null;
	}

	add(name,url){
		this._ref.add({
			[rhit.FB_KEY_IMAGE_URL]: url,
			[rhit.FB_KEY_NAME]: name,
			[rhit.FB_KEY_LAST_TOUCHED]: firebase.firestore.Timestamp.now(),
		})
		// .then(function() {
		// 	console.log("Document successfully written!");
		// })
		// .catch(function(error) {
		// 	console.error("Error writing document: ", error);
		// });
	}

	beginListening(changeListener) {  
		this._unsubscribe = this._ref.onSnapshot((querySnapshot)=> {
			console.log("test update");
			this._documentSnapshots = querySnapshot.docs;
			   console.log(this._documentSnapshots);
			changeListener();    
   		});
	}

	stopListening() {  
		this._unsubscribe();
	}

	getItemAtIndex(index){
		const docSnapchot = this._documentSnapshots[index];
		const oneitem = new rhit.Post(
			docSnapchot.id,
			docSnapchot.get(rhit.FB_KEY_NAME),
			docSnapchot.get(rhit.FB_KEY_IMAGE_URL),
		);
		return oneitem;
	}

	get length(){
		return this._documentSnapshots.length;
	}
}


rhit.FbDetailItemManager = class {
	constructor(id){
	   this._documentSnapshot = {};
	   this._unsubscribe = null;
	   this._ref = firebase.firestore().collection(rhit.FB_COLLECTION_POSTS).doc(id);
		console.log(`Listening to ${this._ref.path}`);
	}

	beginListening(changeListener) {
	   this._unsubscribe = this._ref.onSnapshot((doc) =>{
		   if(doc.exists){
			   console.log("Document data:", doc.data());
			   this._documentSnapshot=doc;
			   changeListener();
		   }else{
			   console.log("No such document");
		   }
	   });
   }

   stopListening() {
	   this._unsubscribe();
   }

   update(Owner, Condition, Name, Description,url ,Type ){
	   this._ref.update({
		   [rhit.FB_KEY_TYPE]: Type,
		   [rhit.FB_KEY_OWNER]: Owner,
		   [rhit.FB_KEY_NAME]: Name,
		   [rhit.FB_KEY_CONDITION]:Condition,
		   [rhit.FB_KEY_DESCRIPTION]: Description,
		   [rhit.FB_KEY_IMAGE_URL]: url,
		   [rhit.FB_KEY_LAST_TOUCHED]: firebase.firestore.Timestamp.now(),
	   })
	   .then(() => {
		   console.log("Document successfully updated!");
	   })
	   .catch(function(error) {
		   console.error("Error writing document: ", error);
	   });
   
   }

//    delete(){
// 	   return this._ref.delete();
//    }

   get url(){
	   return this._documentSnapshot.get(rhit.FB_KEY_IMAGE_URL);
   }

   get Owner(){
		return this._documentSnapshot.get(rhit.FB_KEY_OWNER);
   }

   get Name(){
		return this._documentSnapshot.get(rhit.FB_KEY_NAME);
   }

   get Condition(){
		return this._documentSnapshot.get(rhit.FB_KEY_CONDITION);
   }

   get Description(){
		return this._documentSnapshot.get(rhit.FB_KEY_DESCRIPTION);
   }
}






rhit.initializePage = ()=>{
	// const urlParams = new URLSearchParams(window.location.search);
	// const photoId = urlParams.get("id");
	if(document.querySelector("#loginPage")){
		console.log("object");
			rhit.startFirebaseUI();
			// new rhit.LoginPageController();
		}

		if(document.querySelector("#mainPage")){
			new rhit.HomePageController();
		}

		if(document.querySelector("#ListPage")){
			console.log("You are on the List page");
			// const uid = urlParams.get("uid");
			rhit.fbItemsManager = new rhit.FbItemsManager();
			new rhit.ListPageController();
		}

		if(document.querySelector("#detailPage")){
			const string = window.location.search;
			const urlParams = new URLSearchParams(string);
		 	const id = urlParams.get("id");
			rhit.fbDetailItemManager = new rhit.FbDetailItemManager(id);
			new rhit.DetailPageController();
			
		}


		// 	if (!photoId){

		// 		window.location.href = "/";
		// 	}

		// 	rhit.singlePhotoManager = new rhit.SinglePhotoManager(photoId);
		// 	new rhit.DetailPageController();
		// }
};

rhit.ClassName = class {
	constructor() {

	}

	methodName() {

	}
}

/* Main */
/** function and class syntax examples */
rhit.main = function () {
	console.log("Ready");
	rhit.initializePage();
};

rhit.main();
